﻿namespace test1
{
    partial class SelectOptionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.AwayDay_UI_Panel1 = new MetroFramework.Controls.MetroPanel();
            this.htmlLabel5 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.htmlLabel3 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.htmlLabel4 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.txtbox3_add_facilities = new MetroFramework.Controls.MetroTextBox();
            this.htmlLabel2 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.htmlLabel1 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.txtbox1_clientID = new MetroFramework.Controls.MetroTextBox();
            this.AwayDayGrid1 = new MetroFramework.Controls.MetroGrid();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroComboBox1 = new MetroFramework.Controls.MetroComboBox();
            this.metroDateTime1 = new MetroFramework.Controls.MetroDateTime();
            this.metroComboBox2 = new MetroFramework.Controls.MetroComboBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.requestEstimationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.AwayDay_UI_Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AwayDayGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestEstimationBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // AwayDay_UI_Panel1
            // 
            this.AwayDay_UI_Panel1.Controls.Add(this.metroComboBox2);
            this.AwayDay_UI_Panel1.Controls.Add(this.metroDateTime1);
            this.AwayDay_UI_Panel1.Controls.Add(this.metroComboBox1);
            this.AwayDay_UI_Panel1.Controls.Add(this.AwayDayGrid1);
            this.AwayDay_UI_Panel1.Controls.Add(this.htmlLabel5);
            this.AwayDay_UI_Panel1.Controls.Add(this.htmlLabel3);
            this.AwayDay_UI_Panel1.Controls.Add(this.htmlLabel4);
            this.AwayDay_UI_Panel1.Controls.Add(this.txtbox3_add_facilities);
            this.AwayDay_UI_Panel1.Controls.Add(this.htmlLabel2);
            this.AwayDay_UI_Panel1.Controls.Add(this.htmlLabel1);
            this.AwayDay_UI_Panel1.Controls.Add(this.txtbox1_clientID);
            this.AwayDay_UI_Panel1.HorizontalScrollbarBarColor = true;
            this.AwayDay_UI_Panel1.HorizontalScrollbarHighlightOnWheel = false;
            this.AwayDay_UI_Panel1.HorizontalScrollbarSize = 10;
            this.AwayDay_UI_Panel1.Location = new System.Drawing.Point(38, 63);
            this.AwayDay_UI_Panel1.Name = "AwayDay_UI_Panel1";
            this.AwayDay_UI_Panel1.Size = new System.Drawing.Size(490, 339);
            this.AwayDay_UI_Panel1.TabIndex = 1;
            this.AwayDay_UI_Panel1.VerticalScrollbarBarColor = true;
            this.AwayDay_UI_Panel1.VerticalScrollbarHighlightOnWheel = false;
            this.AwayDay_UI_Panel1.VerticalScrollbarSize = 10;
            this.AwayDay_UI_Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.AwayDay_UI_Panel1_Paint);
            // 
            // htmlLabel5
            // 
            this.htmlLabel5.AutoScroll = true;
            this.htmlLabel5.AutoScrollMinSize = new System.Drawing.Size(125, 25);
            this.htmlLabel5.AutoSize = false;
            this.htmlLabel5.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel5.Location = new System.Drawing.Point(31, 214);
            this.htmlLabel5.Name = "htmlLabel5";
            this.htmlLabel5.Size = new System.Drawing.Size(150, 69);
            this.htmlLabel5.TabIndex = 12;
            this.htmlLabel5.Text = "Additional Facilities";
            // 
            // htmlLabel3
            // 
            this.htmlLabel3.AutoScroll = true;
            this.htmlLabel3.AutoScrollMinSize = new System.Drawing.Size(92, 25);
            this.htmlLabel3.AutoSize = false;
            this.htmlLabel3.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel3.Location = new System.Drawing.Point(31, 123);
            this.htmlLabel3.Name = "htmlLabel3";
            this.htmlLabel3.Size = new System.Drawing.Size(163, 54);
            this.htmlLabel3.TabIndex = 10;
            this.htmlLabel3.Text = "Booking Type";
            this.htmlLabel3.Click += new System.EventHandler(this.htmlLabel3_Click);
            // 
            // htmlLabel4
            // 
            this.htmlLabel4.AutoScroll = true;
            this.htmlLabel4.AutoScrollMinSize = new System.Drawing.Size(137, 25);
            this.htmlLabel4.AutoSize = false;
            this.htmlLabel4.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel4.Location = new System.Drawing.Point(31, 170);
            this.htmlLabel4.Name = "htmlLabel4";
            this.htmlLabel4.Size = new System.Drawing.Size(163, 38);
            this.htmlLabel4.TabIndex = 9;
            this.htmlLabel4.Text = "Planned AwayDay(s) ";
            // 
            // txtbox3_add_facilities
            // 
            // 
            // 
            // 
            this.txtbox3_add_facilities.CustomButton.Image = null;
            this.txtbox3_add_facilities.CustomButton.Location = new System.Drawing.Point(138, 1);
            this.txtbox3_add_facilities.CustomButton.Name = "";
            this.txtbox3_add_facilities.CustomButton.Size = new System.Drawing.Size(101, 101);
            this.txtbox3_add_facilities.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtbox3_add_facilities.CustomButton.TabIndex = 1;
            this.txtbox3_add_facilities.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtbox3_add_facilities.CustomButton.UseSelectable = true;
            this.txtbox3_add_facilities.CustomButton.Visible = false;
            this.txtbox3_add_facilities.Lines = new string[0];
            this.txtbox3_add_facilities.Location = new System.Drawing.Point(200, 214);
            this.txtbox3_add_facilities.MaxLength = 32767;
            this.txtbox3_add_facilities.Multiline = true;
            this.txtbox3_add_facilities.Name = "txtbox3_add_facilities";
            this.txtbox3_add_facilities.PasswordChar = '\0';
            this.txtbox3_add_facilities.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtbox3_add_facilities.SelectedText = "";
            this.txtbox3_add_facilities.SelectionLength = 0;
            this.txtbox3_add_facilities.SelectionStart = 0;
            this.txtbox3_add_facilities.ShortcutsEnabled = true;
            this.txtbox3_add_facilities.Size = new System.Drawing.Size(240, 103);
            this.txtbox3_add_facilities.TabIndex = 8;
            this.txtbox3_add_facilities.UseSelectable = true;
            this.txtbox3_add_facilities.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtbox3_add_facilities.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // htmlLabel2
            // 
            this.htmlLabel2.AutoScroll = true;
            this.htmlLabel2.AutoScrollMinSize = new System.Drawing.Size(90, 25);
            this.htmlLabel2.AutoSize = false;
            this.htmlLabel2.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel2.Location = new System.Drawing.Point(31, 77);
            this.htmlLabel2.Name = "htmlLabel2";
            this.htmlLabel2.Size = new System.Drawing.Size(126, 52);
            this.htmlLabel2.TabIndex = 6;
            this.htmlLabel2.Text = "Planned Date";
            // 
            // htmlLabel1
            // 
            this.htmlLabel1.AutoScroll = true;
            this.htmlLabel1.AutoScrollMinSize = new System.Drawing.Size(176, 25);
            this.htmlLabel1.AutoSize = false;
            this.htmlLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel1.Location = new System.Drawing.Point(31, 31);
            this.htmlLabel1.Name = "htmlLabel1";
            this.htmlLabel1.Size = new System.Drawing.Size(369, 40);
            this.htmlLabel1.TabIndex = 4;
            this.htmlLabel1.Text = "Please Fill the Enquiry form";
            this.htmlLabel1.Click += new System.EventHandler(this.htmlLabel1_Click);
            // 
            // txtbox1_clientID
            // 
            // 
            // 
            // 
            this.txtbox1_clientID.CustomButton.Image = null;
            this.txtbox1_clientID.CustomButton.Location = new System.Drawing.Point(-12, 1);
            this.txtbox1_clientID.CustomButton.Name = "";
            this.txtbox1_clientID.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtbox1_clientID.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtbox1_clientID.CustomButton.TabIndex = 1;
            this.txtbox1_clientID.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtbox1_clientID.CustomButton.UseSelectable = true;
            this.txtbox1_clientID.CustomButton.Visible = false;
            this.txtbox1_clientID.Lines = new string[0];
            this.txtbox1_clientID.Location = new System.Drawing.Point(200, 31);
            this.txtbox1_clientID.MaxLength = 32767;
            this.txtbox1_clientID.Name = "txtbox1_clientID";
            this.txtbox1_clientID.PasswordChar = '\0';
            this.txtbox1_clientID.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtbox1_clientID.SelectedText = "";
            this.txtbox1_clientID.SelectionLength = 0;
            this.txtbox1_clientID.SelectionStart = 0;
            this.txtbox1_clientID.ShortcutsEnabled = true;
            this.txtbox1_clientID.Size = new System.Drawing.Size(10, 23);
            this.txtbox1_clientID.TabIndex = 3;
            this.txtbox1_clientID.UseSelectable = true;
            this.txtbox1_clientID.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtbox1_clientID.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtbox1_clientID.Click += new System.EventHandler(this.txtbox1_clientID_Click);
            // 
            // AwayDayGrid1
            // 
            this.AwayDayGrid1.AllowUserToResizeRows = false;
            this.AwayDayGrid1.AutoGenerateColumns = false;
            this.AwayDayGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AwayDayGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AwayDayGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.AwayDayGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AwayDayGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.AwayDayGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AwayDayGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.AwayDayGrid1.DataSource = this.requestEstimationBindingSource;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.AwayDayGrid1.DefaultCellStyle = dataGridViewCellStyle8;
            this.AwayDayGrid1.EnableHeadersVisualStyles = false;
            this.AwayDayGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.AwayDayGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.AwayDayGrid1.Location = new System.Drawing.Point(746, -47);
            this.AwayDayGrid1.Name = "AwayDayGrid1";
            this.AwayDayGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.AwayDayGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.AwayDayGrid1.RowHeadersWidth = 51;
            this.AwayDayGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.AwayDayGrid1.RowTemplate.Height = 24;
            this.AwayDayGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AwayDayGrid1.Size = new System.Drawing.Size(373, 41);
            this.AwayDayGrid1.TabIndex = 6;
            this.AwayDayGrid1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AwayDayGrid1_CellContentClick);
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(120, 430);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 7;
            this.metroButton1.Text = "Submit";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click_1);
            // 
            // metroComboBox1
            // 
            this.metroComboBox1.FormattingEnabled = true;
            this.metroComboBox1.ItemHeight = 24;
            this.metroComboBox1.Items.AddRange(new object[] {
            "Booking Service",
            "Booking Service with Facilitated session"});
            this.metroComboBox1.Location = new System.Drawing.Point(200, 123);
            this.metroComboBox1.Name = "metroComboBox1";
            this.metroComboBox1.Size = new System.Drawing.Size(240, 30);
            this.metroComboBox1.TabIndex = 14;
            this.metroComboBox1.UseSelectable = true;
            // 
            // metroDateTime1
            // 
            this.metroDateTime1.Location = new System.Drawing.Point(200, 77);
            this.metroDateTime1.MinimumSize = new System.Drawing.Size(0, 30);
            this.metroDateTime1.Name = "metroDateTime1";
            this.metroDateTime1.Size = new System.Drawing.Size(200, 30);
            this.metroDateTime1.TabIndex = 15;
            this.metroDateTime1.ValueChanged += new System.EventHandler(this.metroDateTime1_ValueChanged);
            // 
            // metroComboBox2
            // 
            this.metroComboBox2.FormattingEnabled = true;
            this.metroComboBox2.ItemHeight = 24;
            this.metroComboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.metroComboBox2.Location = new System.Drawing.Point(201, 170);
            this.metroComboBox2.Name = "metroComboBox2";
            this.metroComboBox2.Size = new System.Drawing.Size(121, 30);
            this.metroComboBox2.TabIndex = 16;
            this.metroComboBox2.UseSelectable = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "clientID";
            this.dataGridViewTextBoxColumn1.HeaderText = "clientID";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "plannedFromDate";
            this.dataGridViewTextBoxColumn2.HeaderText = "plannedFromDate";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "bookingServiceType";
            this.dataGridViewTextBoxColumn3.HeaderText = "bookingServiceType";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "plannedAwayDays";
            this.dataGridViewTextBoxColumn4.HeaderText = "plannedAwayDays";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "AdditionalFacilityDescription";
            this.dataGridViewTextBoxColumn5.HeaderText = "AdditionalFacilityDescription";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 125;
            // 
            // requestEstimationBindingSource
            // 
            this.requestEstimationBindingSource.DataSource = typeof(test1.RequestEstimation);
            this.requestEstimationBindingSource.CurrentChanged += new System.EventHandler(this.requestEstimationBindingSource_CurrentChanged);
            // 
            // SelectOptionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 555);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.AwayDay_UI_Panel1);
            this.Name = "SelectOptionsForm";
            this.Text = "Initial Enquiry Form";
            this.TransparencyKey = System.Drawing.Color.SkyBlue;
            this.Load += new System.EventHandler(this.SelectOptionsForm_Load);
            this.AwayDay_UI_Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AwayDayGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestEstimationBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private MetroFramework.Controls.MetroPanel AwayDay_UI_Panel1;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel1;
        private MetroFramework.Controls.MetroTextBox txtbox1_clientID;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel2;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel3;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel4;
        private MetroFramework.Controls.MetroTextBox txtbox3_add_facilities;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel5;
        private MetroFramework.Controls.MetroGrid AwayDayGrid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn plannedFromDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookingServiceTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn plannedAwayDaysDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn additionalFacilityDescriptionDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.BindingSource requestEstimationBindingSource;
        private MetroFramework.Controls.MetroComboBox metroComboBox1;
        private MetroFramework.Controls.MetroDateTime metroDateTime1;
        private MetroFramework.Controls.MetroComboBox metroComboBox2;
    }
}

