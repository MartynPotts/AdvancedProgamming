﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test1
{
    public class ChooseOptionsContext : DbContext
    {
        public  DbSet<RequestEstimation> RequestEstimations
        {
            get;
            set;
        }
        
    }
}
