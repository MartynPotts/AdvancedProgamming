﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test1
{
    public partial class SelectOptionsForm : MetroFramework.Forms.MetroForm
    {
        // RequestEstimate re;
        ChooseOptionsContext db;
        public SelectOptionsForm()
        {
            InitializeComponent();
        }


        private void metroTextBox3_Click(object sender, EventArgs e)
        {

        }

        private void htmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void htmlLabel3_Click(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            //if (MetroFramework.MetroMessageBox.Show(this, "Are u sure you sure u want to exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            { }
        }

        private void Awayday_UI_Grid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void SelectOptionsForm_Load(object sender, EventArgs e)
        {
            db = new ChooseOptionsContext();
            {
                requestEstimationBindingSource.DataSource = db.RequestEstimations.ToList();

            }
           


            
           // RequestEstimation obj = requestEstimationBindingSource.Current as RequestEstimation;
        }

        private void AwayDay_UI_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }


        private void AwayDayGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            RequestEstimation obj = requestEstimationBindingSource.Current as RequestEstimation;

        }

        private void metroButton1_Click_1(object sender, EventArgs e)
        {

            //try
            //{


            //    requestEstimationBindingSource.Add(new RequestEstimation());
            //    requestEstimationBindingSource.MoveLast();

            //    txtbox1_clientID.Focus();

            //    RequestEstimation obj = requestEstimationBindingSource.Current as RequestEstimation;


            //    using (ChooseOptionsContext db = new ChooseOptionsContext())
            //    {
            //        if (obj != null)
            //        {



            //                    db.Entry<RequestEstimation>(obj).State = System.Data.Entity.EntityState.Added;

            //                db.SaveChanges();
            //                MetroFramework.MetroMessageBox.Show(this, "savedddddd");
            //        }

            //        else
            //        {
            //            MetroFramework.MetroMessageBox.Show(this, "errorrrrr");
            //        }
            //    }

            //}
            //catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            //{
            //    foreach (var eve in ex.EntityValidationErrors)
            //    {
            //        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
            //            eve.Entry.Entity.GetType().Name, eve.Entry.State);
            //        foreach (var ve in eve.ValidationErrors)
            //        {
            //            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
            //                ve.PropertyName, ve.ErrorMessage);
            //        }
            //    }
            //    throw;
            //}


            int i = Convert.ToInt32(metroComboBox2.Text);
            

            requestEstimationBindingSource.Add(new RequestEstimation());
            requestEstimationBindingSource.MoveLast();
            metroDateTime1.Focus();
            using (ChooseOptionsContext db = new ChooseOptionsContext())
            {
                RequestEstimation obj = requestEstimationBindingSource.Current as RequestEstimation;
                string bookingType = metroComboBox1.Text.ToString();
                string fromDate = metroDateTime1.Text.ToString();
                string facilityDescription = metroComboBox2.Text.ToString();

                obj.plannedFromDate = fromDate;
                obj.bookingServiceType = bookingType;
                obj.plannedAwayDays = i;
                obj.AdditionalFacilityDescription = facilityDescription;

                if (obj != null)
                {
                    if (db.Entry<RequestEstimation>(obj).State == EntityState.Detached)
                        db.Set <RequestEstimation>().Attach(obj);
                    if (obj.clientID == 0)
                        db.Entry<RequestEstimation>(obj).State = EntityState.Added;
                    else
                        db.Entry<RequestEstimation>(obj).State = EntityState.Modified;
                    db.SaveChanges();
                    MetroFramework.MetroMessageBox.Show(this, "savedddddd");
                }
              
            }






          
        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void txtbox1_clientID_Click(object sender, EventArgs e)
        {
          
        }

        private void requestEstimationBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void metroDateTime1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
